# Convert all kind inputs to our format

# Input:
  ONNX
  PYTORCH
  PROTOTXT


# Output:
  CSV
  JSON

