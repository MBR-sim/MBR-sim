# MBR-SIM: A Speed-of-Light Model for ML Accelerators

Sample Command:
python3 src/mbr-sim.py workloads/csv/ResNet50.csv 512 32 16 64

Authors: Ben Maydan, Mehul Goel, Raj Parihar
